-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 15, 2016 at 07:49 AM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `senk`
--

-- --------------------------------------------------------

--
-- Table structure for table `controbution`
--

CREATE TABLE IF NOT EXISTS `controbution` (
  `Controbution-ID` int(14) NOT NULL AUTO_INCREMENT,
  `MemberID` varchar(34) NOT NULL,
  `Amount` int(34) NOT NULL,
  PRIMARY KEY (`Controbution-ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `controbution`
--

INSERT INTO `controbution` (`Controbution-ID`, `MemberID`, `Amount`) VALUES
(1, '100001', 25600),
(2, '100026', 20000),
(3, '100003', 20000),
(4, '100026', 1222),
(5, '100026', 10000),
(6, '100021', 888888),
(7, '100021', 888888);

-- --------------------------------------------------------

--
-- Table structure for table `event`
--

CREATE TABLE IF NOT EXISTS `event` (
  `Event-ID` int(14) NOT NULL AUTO_INCREMENT,
  `Title` varchar(20) NOT NULL,
  `Date` date NOT NULL,
  `Venue` varchar(32) NOT NULL,
  `Start-tym` time NOT NULL,
  `End-tym` time NOT NULL,
  `Description` varchar(34) NOT NULL,
  `Created-by` varchar(20) NOT NULL,
  PRIMARY KEY (`Event-ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `event`
--

INSERT INTO `event` (`Event-ID`, `Title`, `Date`, `Venue`, `Start-tym`, `End-tym`, `Description`, `Created-by`) VALUES
(7, 'Google Development', '2015-09-19', 'IUEA', '11:00:00', '16:00:03', 'Google Apps ', '300011'),
(8, 'Jinja Tour', '2015-06-24', 'Jinja Hall', '12:00:00', '16:00:04', 'Skills Improvement', '300011'),
(12, 'NBS', '2015-08-25', 'Kajjansi', '15:00:00', '17:00:03', 'Fund raising', '300011'),
(13, 'Bukedde', '2015-08-25', 'Gabba', '14:00:00', '16:00:09', 'i do', '300011');

-- --------------------------------------------------------

--
-- Table structure for table `get`
--

CREATE TABLE IF NOT EXISTS `get` (
  `loanID` int(9) NOT NULL AUTO_INCREMENT,
  `MemberID` int(6) NOT NULL,
  `tol` varchar(34) NOT NULL,
  `mop` varchar(34) NOT NULL,
  `moth` varchar(34) NOT NULL,
  `ea` varchar(34) NOT NULL,
  `ir` varchar(34) NOT NULL,
  `ta` varchar(34) NOT NULL,
  `rd` date NOT NULL,
  `sd` date NOT NULL,
  `md` date NOT NULL,
  `Status` varchar(14) NOT NULL,
  PRIMARY KEY (`loanID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=45 ;

--
-- Dumping data for table `get`
--

INSERT INTO `get` (`loanID`, `MemberID`, `tol`, `mop`, `moth`, `ea`, `ir`, `ta`, `rd`, `sd`, `md`, `Status`) VALUES
(44, 300012, 'School Loan', 'Monthly', '3', '70000', '0.11', '93100', '2016-03-15', '2016-03-16', '2016-06-16', 'Aproved');

-- --------------------------------------------------------

--
-- Table structure for table `instale-history`
--

CREATE TABLE IF NOT EXISTS `instale-history` (
  `PayID` int(12) NOT NULL AUTO_INCREMENT,
  `MemberID` int(12) NOT NULL,
  `Balance` int(12) NOT NULL,
  `Installement` int(12) NOT NULL,
  `Current_Balance` int(20) NOT NULL,
  `Date` date NOT NULL,
  `Paid_By` varchar(12) NOT NULL,
  `Aproved_by` varchar(12) NOT NULL,
  PRIMARY KEY (`PayID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=27 ;

--
-- Dumping data for table `instale-history`
--

INSERT INTO `instale-history` (`PayID`, `MemberID`, `Balance`, `Installement`, `Current_Balance`, `Date`, `Paid_By`, `Aproved_by`) VALUES
(16, 100026, 115200, 10000, 105200, '2015-10-06', 'Grace Cibale', 'Mr. Mwesige '),
(17, 100003, 0, 600000, 600000, '2015-04-11', '100003', '100002'),
(18, 100026, 510000, 10000, 500000, '0000-00-00', '100026', '300012'),
(19, 0, 0, 4000, 157796000, '0000-00-00', '300012', '300012'),
(20, 0, 0, 4000, 157796000, '0000-00-00', '300012', '300012'),
(21, 0, 0, 7777, 1452223, '0000-00-00', '100026', '300012'),
(22, 0, 0, 7777, 1452223, '0000-00-00', '100026', '300012'),
(23, 0, 0, 7777, 1452223, '0000-00-00', '100026', '300012'),
(24, 0, 0, 56000, 157744000, '0000-00-00', '100026', '300012'),
(25, 300012, 0, 10000, 0, '2016-03-15', '300012', '300012'),
(26, 300012, 0, 10000, 0, '2016-03-15', '300012', '300012');

-- --------------------------------------------------------

--
-- Table structure for table `loan`
--

CREATE TABLE IF NOT EXISTS `loan` (
  `id` int(19) NOT NULL AUTO_INCREMENT,
  `MemberID` int(12) NOT NULL,
  `Total` int(23) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `loan`
--

INSERT INTO `loan` (`id`, `MemberID`, `Total`) VALUES
(1, 300012, 93100);

-- --------------------------------------------------------

--
-- Table structure for table `loaner`
--

CREATE TABLE IF NOT EXISTS `loaner` (
  `id` int(23) NOT NULL AUTO_INCREMENT,
  `MemberID` int(23) NOT NULL,
  `Sum` int(23) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `loaner`
--

INSERT INTO `loaner` (`id`, `MemberID`, `Sum`) VALUES
(1, 300012, 83100);

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE IF NOT EXISTS `logs` (
  `ID` int(15) NOT NULL AUTO_INCREMENT,
  `senkid` varchar(14) NOT NULL,
  `LName` varchar(14) NOT NULL,
  `Password` varchar(15) NOT NULL,
  `number` int(16) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

--
-- Dumping data for table `logs`
--

INSERT INTO `logs` (`ID`, `senkid`, `LName`, `Password`, `number`) VALUES
(2, 'Grace', 'Cibale', 'kinshasa', 100026),
(3, 'Mwesige', 'Eden', 'eden', 300012),
(4, 'Amos', 'Job', 'eric', 300018),
(5, 'Kato', 'Diago', 'jones', 300018),
(18, 'MIke', 'Bob', 'who', 300023),
(19, 'mikael', 'amstrong', 'wabuki', 100039),
(21, 'Kato Kato', 'Diago', 'jones', 300011),
(22, 'Kibirige', 'John', 'johnsjohns', 300013),
(23, 'Nansana', 'Milk', '12345', 100041),
(24, 'hhh', 'hhhh', 'ffff', 100042);

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE IF NOT EXISTS `members` (
  `MemberID` int(9) NOT NULL AUTO_INCREMENT,
  `FName` varchar(20) NOT NULL,
  `LName` varchar(20) NOT NULL,
  `DOB` date NOT NULL,
  `Address` varchar(20) NOT NULL,
  `Phone` int(12) NOT NULL,
  `Password` varchar(20) NOT NULL,
  `Gender` varchar(20) NOT NULL,
  `National-ID` int(20) NOT NULL,
  PRIMARY KEY (`MemberID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=100043 ;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`MemberID`, `FName`, `LName`, `DOB`, `Address`, `Phone`, `Password`, `Gender`, `National-ID`) VALUES
(100026, 'Grace', 'Cibale', '1908-02-03', 'Kansanga', 752459734, 'kinshasa', 'Female', 245464255),
(100027, 'sentongo', 'Hadaadi', '1902-12-10', 'kasaga', 988277277, '123', 'Male', 34667865),
(100029, 'shaima', 'mohamed', '1992-06-11', 'kansanga', 783364016, 'nakisuyi', 'Female', 234567587),
(100032, 'Wassaw', 'Doe', '1991-06-14', 'kansanga', 2147483647, 'deowa', 'Male', 163527189),
(100039, 'mikael', 'amstrong', '1985-05-15', 'Buziga Upper', 75678964, 'wabuki', 'Male', 132334545),
(100040, 'gracec', 'grace', '0000-00-00', 'Buziga Lowwer', 765433219, 'grace', 'Female', 123456789),
(100041, 'Nansana', 'Milk', '1992-08-09', 'Buziga Upper', 786567647, '12345', 'Male', 123456789),
(100042, 'hhh', 'hhhh', '0000-00-00', 'Buziga Upper', 6556788, 'ffff', 'Male', 455675787);

-- --------------------------------------------------------

--
-- Table structure for table `save`
--

CREATE TABLE IF NOT EXISTS `save` (
  `Save-ID` int(23) NOT NULL AUTO_INCREMENT,
  `MemberID` int(14) NOT NULL,
  `Intial` int(15) NOT NULL,
  `Total` int(15) NOT NULL,
  PRIMARY KEY (`Save-ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=41 ;

--
-- Dumping data for table `save`
--

INSERT INTO `save` (`Save-ID`, `MemberID`, `Intial`, `Total`) VALUES
(31, 300012, 315590000, 310000000),
(32, 100026, 1400000, 1460000),
(36, 100033, 300000, 345000),
(38, 100036, 0, 1000000),
(40, 100041, 0, 1920000);

-- --------------------------------------------------------

--
-- Table structure for table `save-history`
--

CREATE TABLE IF NOT EXISTS `save-history` (
  `HistoryID` int(12) NOT NULL AUTO_INCREMENT,
  `MemberID` int(12) NOT NULL,
  `Date` date NOT NULL,
  `Amount` int(12) NOT NULL,
  `saved-by` varchar(12) NOT NULL,
  `Recieved-By` varchar(12) NOT NULL,
  PRIMARY KEY (`HistoryID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `save-history`
--

INSERT INTO `save-history` (`HistoryID`, `MemberID`, `Date`, `Amount`, `saved-by`, `Recieved-By`) VALUES
(1, 300012, '2015-03-17', 98890000, '300012', '300012'),
(2, 100026, '2015-04-23', 210000, '100026', '300012'),
(3, 100026, '2015-06-11', 300000, '100026', '300012'),
(4, 100026, '2015-02-24', 1000000, '100026', '300012'),
(5, 100026, '2015-06-18', 1000000, '100026', '300012'),
(6, 100033, '2015-06-22', 300000, 'Hadda', '300012'),
(7, 100033, '2015-06-22', 50000, 'Hadda', '300012'),
(8, 100036, '2015-06-23', 1000000, '100036', '300012'),
(9, 100026, '2015-08-11', 60000, '100026', '300012'),
(10, 100041, '2015-08-14', 2000000, '100041', '300012'),
(11, 300012, '2016-03-15', 70000, '30012', '300012');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE IF NOT EXISTS `staff` (
  `StaffID` int(10) NOT NULL AUTO_INCREMENT,
  `FName` varchar(20) NOT NULL,
  `LName` varchar(20) NOT NULL,
  `DOB` date NOT NULL,
  `Address` varchar(20) NOT NULL,
  `Password` varchar(15) NOT NULL,
  `Designation` varchar(20) NOT NULL,
  PRIMARY KEY (`StaffID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=300019 ;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`StaffID`, `FName`, `LName`, `DOB`, `Address`, `Password`, `Designation`) VALUES
(300011, 'Kato Kato', 'Diago', '1970-02-08', 'Katwe', 'jones', 'Chairman'),
(300012, 'Mwesige', 'Eden', '1981-03-06', 'Kasanga', 'eden', 'Teller'),
(300013, 'Kibirige', 'John', '1962-09-23', 'Ggaba', 'johnsjohns', 'System Admin'),
(300018, 'Amos', 'Job', '1990-08-16', 'Kamukya', 'eric', 'Chairman');

-- --------------------------------------------------------

--
-- Table structure for table `withdraw`
--

CREATE TABLE IF NOT EXISTS `withdraw` (
  `WithdrawID` int(16) NOT NULL AUTO_INCREMENT,
  `MemberID` int(12) NOT NULL,
  `Date` date NOT NULL,
  `withdrew` int(12) NOT NULL,
  `Recieved` varchar(12) NOT NULL,
  PRIMARY KEY (`WithdrawID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `withdraw`
--

INSERT INTO `withdraw` (`WithdrawID`, `MemberID`, `Date`, `withdrew`, `Recieved`) VALUES
(1, 100026, '2015-05-23', 80000, '300012'),
(2, 100026, '2015-06-10', 10000, '300012'),
(3, 100026, '2015-06-19', 5000, '300012'),
(4, 100026, '2015-06-19', 5000, '300012'),
(5, 100026, '2015-06-19', 5000, '300012'),
(6, 100026, '2015-06-19', 5000, '300012'),
(7, 300012, '2015-06-20', 90000, '300012'),
(8, 100026, '2015-06-22', 5000, '300012'),
(9, 100033, '2015-06-23', 5000, '300012'),
(10, 100026, '2015-06-24', 5000, '300011'),
(11, 100026, '2015-08-11', 60000, '300012'),
(12, 100026, '2015-08-11', 5000, '300012'),
(13, 100041, '2015-08-14', 70000, '300012'),
(14, 100041, '2016-02-20', 10000, '300011'),
(15, 300012, '2016-03-15', 5660000, '300012');
